


function Events () {
  return (
    <div>
        <h1> Events page</h1>
        </div>
    

  );


}

export default Events ;