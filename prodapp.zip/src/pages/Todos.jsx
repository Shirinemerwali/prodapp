


function Todos () {

return (
    <div>
    <h1> Todo page</h1>

    </div>


);


}

export default Todos ;
